<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_bb3e3e0b2d6483a236feb8df3a0f7b0b80f059e6253c9f36d576ea8d1bbf6e9d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>
<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\">
<head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />
    <title>";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    <script language=\"javascript\" src=\"/static/jquery-1.7.1.min.js\"></script>
    <script language=\"JavaScript\" src=\"/static/FrameWork.js?1608414182\"></script>
    <script language=\"JavaScript\" src=\"/static/MysqlCenter.js?1608414502\"></script>
    <script language=\"javascript\">
    var debug = '1';
    </script>
    <link rel=\"stylesheet\" type=\"text/css\" href=\"/static/page.css\" />
    <link rel=\"stylesheet\" type=\"text/css\" href=\"/static/color.white.css\" />
    <link rel=\"shortcut icon\" href=\"/favicon.ico\"/>
</head>
<body>
<div class=\"pageBlock\">
  <b id=\"appNameId\"><a href=\"";
        // line 19
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("db_list");
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["MS_APP_NAME"]) || array_key_exists("MS_APP_NAME", $context) ? $context["MS_APP_NAME"] : (function () { throw new RuntimeError('Variable "MS_APP_NAME" does not exist.', 19, $this->source); })()), "html", null, true);
        echo "</a></b>

<div class=\"globalMenu\" id=\"globalMenu\">
    ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["menu"]) || array_key_exists("menu", $context) ? $context["menu"] : (function () { throw new RuntimeError('Variable "menu" does not exist.', 22, $this->source); })()));
        foreach ($context['_seq'] as $context["key"] => $context["value"]) {
            // line 23
            echo "        ";
            if (((0 === twig_compare($context["key"], "[delim]1")) || (0 === twig_compare($context["key"], "[delim]2")))) {
                // line 24
                echo "            <b class=\"delim\">|</b>
        ";
            } else {
                // line 26
                echo "            ";
                $context["cls"] = "";
                // line 27
                echo "            ";
                if (twig_in_filter("очистить", $context["key"])) {
                    // line 28
                    echo "                ";
                    $context["cls"] = " class=truncate";
                    // line 29
                    echo "            ";
                }
                // line 30
                echo "            ";
                if (twig_in_filter("удалить", $context["key"])) {
                    // line 31
                    echo "                ";
                    $context["cls"] = " class=delete";
                    // line 32
                    echo "            ";
                }
                // line 33
                echo "            <a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(twig_get_attribute($this->env, $this->source, $context["value"], 0, [], "array", false, false, false, 33), twig_get_attribute($this->env, $this->source, $context["value"], 1, [], "array", false, false, false, 33)), "html", null, true);
                echo "\" ";
                echo twig_escape_filter($this->env, (isset($context["cls"]) || array_key_exists("cls", $context) ? $context["cls"] : (function () { throw new RuntimeError('Variable "cls" does not exist.', 33, $this->source); })()), "html", null, true);
                echo ">";
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo "</a>
        ";
            }
            // line 35
            echo "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['value'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 36
        echo "</div>
 &nbsp; &nbsp;
  <span class=\"hiddenText\" onclick=\"msDisplaySql()\" title=\"Кликните, чтобы открыть форму быстрого запроса\">0.02138 с. &nbsp;&nbsp;  </span>
  <span class=\"menuChain\"><!-- TODO цепочка меню -->
      <a href=\"";
        // line 40
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("db_list");
        echo "\">DB</a> &nbsp;
      <a href=\"";
        // line 41
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("tbl_list", ["db" => (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 41, $this->source); })()), "action" => "structure"]), "html", null, true);
        echo "\">&#8250;</a> &nbsp;
      <a href=\"";
        // line 42
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("tbl_list", ["db" => (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 42, $this->source); })())]), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 42, $this->source); })()), "html", null, true);
        echo "</a>
  </span>
</div>
<table width=\"100%\" class=\"outerTable\">
  <tr>
    <td width=\"100\" class=\"tableMenuTd\">

<div class=\"menuTables\">
    ";
        // line 50
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["tables"]) || array_key_exists("tables", $context) ? $context["tables"] : (function () { throw new RuntimeError('Variable "tables" does not exist.', 50, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["table"]) {
            // line 51
            echo "      <a class=\"t2\" href=\"";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("tbl_data", ["db" => (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 51, $this->source); })()), "table" => $context["table"]]), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $context["table"], "html", null, true);
            echo "</a>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['table'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 53
        echo "</div>
      <img src=\"/static/images/spacer.png\" width=\"100\" height=\"1\" />
    </td>
    <td>
      <table width=\"800\" border=0 cellspacing=0 cellpadding=0><tr>
        <td width=\"500\"><h1>";
        // line 58
        echo twig_escape_filter($this->env, (isset($context["h1"]) || array_key_exists("h1", $context) ? $context["h1"] : (function () { throw new RuntimeError('Variable "h1" does not exist.', 58, $this->source); })()), "html", null, true);
        echo "</h1></td>
        <td style=\"white-space:nowrap\">
        <span class=\"hiddenText\" onclick=\"showhide(get('queryPopupBlock')); return false\">запросы&nbsp;</span>
        9        &nbsp;&nbsp;
        <form action=\"";
        // line 62
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("search", ["db" => (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 62, $this->source); })())]), "html", null, true);
        echo "\" method=\"post\" style=\"display:inline\" onsubmit=\"this.action=this.action+'&query='+this.query.value\">
        <input type=\"text\" name=\"query\" value=\"Поиск по базе\" onfocus=\"this.value=''\" />
        </form>
        </td></tr>

    </table>


        ";
        // line 70
        ob_start();
        // line 71
        echo "        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 71, $this->source); })()), "flashes", [], "any", false, false, false, 71));
        foreach ($context['_seq'] as $context["label"] => $context["messages"]) {
            // line 72
            echo "            ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["messages"]);
            foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                // line 73
                echo "                <div class=\"flash-";
                echo twig_escape_filter($this->env, $context["label"], "html", null, true);
                echo "\">
                    ";
                // line 74
                echo twig_escape_filter($this->env, $context["message"], "html", null, true);
                echo "
                </div>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 77
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['label'], $context['messages'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 78
        echo "        ";
        $context["flashContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 79
        echo "
        ";
        // line 80
        if (twig_spaceless((isset($context["flashContent"]) || array_key_exists("flashContent", $context) ? $context["flashContent"] : (function () { throw new RuntimeError('Variable "flashContent" does not exist.', 80, $this->source); })()))) {
            // line 81
            echo "        <table class=\"globalMessage\">  <tbody>
            <tr><th>Сообщение <a href=\"#\" class=\"hiddenSmallLink\" style=\"color:#fff\" onclick=\"showhide('mid1636792540')\">close</a></th></tr>
            <tr id=\"mid1636792540\">
                <td>";
            // line 84
            echo twig_escape_filter($this->env, (isset($context["flashContent"]) || array_key_exists("flashContent", $context) ? $context["flashContent"] : (function () { throw new RuntimeError('Variable "flashContent" does not exist.', 84, $this->source); })()), "html", null, true);
            echo "</td>
            </tr></tbody>
        </table>
        ";
        }
        // line 88
        echo "
        ";
        // line 89
        $this->displayBlock('content', $context, $blocks);
        // line 90
        echo "
    </td>
    <td><div id=\"msAjaxQueryDiv\"></div></td>
  </tr>
</table>
<form action=\"";
        // line 95
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("sql", ["db" => (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 95, $this->source); })())]), "html", null, true);
        echo "\" class=\"popupGeneralForm tableFormEdit\" method=\"post\" name=\"sqlPopupQueryForm\" id=\"sqlPopupQueryForm\" style=\"text-align:right\">
  <input type=\"submit\" value=\"Отправить запрос!\" />
  <textarea name=\"sql\" rows=\"15\" wrap=\"off\"></textarea>
  <a href=\"#\" onclick=\"msDisplaySql(); return false\">закрыть</a>
</form>
<div id=\"dbHiddenMenu\">
    ";
        // line 101
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["databases"]) || array_key_exists("databases", $context) ? $context["databases"] : (function () { throw new RuntimeError('Variable "databases" does not exist.', 101, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["db"]) {
            // line 102
            echo "        <a href=\"?db=";
            echo twig_escape_filter($this->env, $context["db"], "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $context["db"], "html", null, true);
            echo "</a><br />
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['db'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 104
        echo "</div>
<div id=\"queryPopupBlock\">
<!-- TODO список запросов -->
</div>
var
<div class=\"pageBlock\">
\t<div class=\"globalMenu\">
  <a href=\"";
        // line 111
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("msc_help", ["db" => (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 111, $this->source); })())]), "html", null, true);
        echo "\"><img src=\"/static/images/help.gif\" alt=\"\" border=\"0\" title=\"MySQL справка\" align=\"absbottom\" /></a>
  <a href=\"";
        // line 112
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("msc_configuration", ["db" => (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 112, $this->source); })())]), "html", null, true);
        echo "\">Настройки</a>
</div>
 &nbsp;&nbsp;&nbsp;
  &nbsp; &nbsp; &nbsp;
  <strong>Хост:</strong> localhost &nbsp;&nbsp;
  <strong>Пользователь:</strong> root &nbsp;&nbsp;
  пиковая память x Mb &nbsp;
  сейчас ";
        // line 119
        echo twig_escape_filter($this->env, (isset($context["memory_get_usage"]) || array_key_exists("memory_get_usage", $context) ? $context["memory_get_usage"] : (function () { throw new RuntimeError('Variable "memory_get_usage" does not exist.', 119, $this->source); })()), "html", null, true);
        echo "
  inc x Kb  limit xM &nbsp; &nbsp;&nbsp;

  <strong><a href=\"";
        // line 122
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("logout");
        echo "\">Выход</a></strong>
</div>
<script language=\"javascript\">
hideTimeout = null;
\$('#appNameId').mouseover(function () {
\t\$('#dbHiddenMenu').show();
})
function menuHidder(e) {
  var w = parseInt(\$('#dbHiddenMenu').width());
  if (e.pageX > w) {
  \thideTimeout = setTimeout(function() {
  \t\t\$('#dbHiddenMenu').hide()
  \t}, 300);
  }
}

\$('#dbHiddenMenu').mouseout(menuHidder);

\$('#dbHiddenMenu').mouseover(function (e) {
\tif (hideTimeout != null) {
\t\tclearInterval(hideTimeout);
\t}
})
\$('#dbHiddenMenu').on('click', function (e) {
    \$('#dbHiddenMenu').hide();
})
\$('#queryPopupBlock').hide()

\$(document).ready(function(){
    \$('.confirm').on('click', function() {
        if (!confirm('Подтвердите действие')) {
            return false;
        }
    })
});


// Определяет активность клавиши CTRL
var globalCtrlKeyMode = false;
var key = {
\tneedkey:function(e) {
\t\tvar code;
\t\tif (!e) var e = window.event;
\t\tif (e.keyCode) code = e.keyCode;
\t\telse if (e.which) code = e.which;
        if (globalCtrlKeyMode == true) {
            globalCtrlKeyMode = false;
        }
\t\tif (e.ctrlKey == true && e.type == 'keydown') {
            globalCtrlKeyMode = true;
        }
\t}
}
if (document.getElementById) {
\tdocument.onkeydown = key.needkey;
\tdocument.onkeyup = key.needkey;
}

// Мультиселектор чекбоксов. Указать индекс чекбокса и селектор элемента где он находится
// <input name=\"table[]\" type=\"checkbox\" value=\"1\" onclick=\"checkboxer(5, '#row');\">
var globalCheckboxLastIndex = null;
function checkboxer(index, selector) {
    if (globalCheckboxLastIndex == null) {
    \tglobalCheckboxLastIndex = index;
    \t//return true;
    } else if (globalCtrlKeyMode && index != globalCheckboxLastIndex) {
    \tvar from = globalCheckboxLastIndex > index ? index : globalCheckboxLastIndex;
    \tvar to = globalCheckboxLastIndex > index ? globalCheckboxLastIndex : index;
        // Добавляем класс если надо
    \tvar addClass = null;
        if (jQuery(selector+from).hasClass('selectedRow') || jQuery(selector+to).hasClass('selectedRow')) {
        \tvar addClass = 'selectedRow';
        }
        for (var i = from; i <= to; i ++) {
            var o = jQuery(selector+i+' input');
           \to.attr('checked', true);
            if (addClass != null) {
            \tjQuery(selector+i).addClass(addClass);
            }
        }
    }
}
</script>
</html>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 6
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 6, $this->source); })()), "html", null, true);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 89
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  410 => 89,  397 => 6,  305 => 122,  299 => 119,  289 => 112,  285 => 111,  276 => 104,  265 => 102,  261 => 101,  252 => 95,  245 => 90,  243 => 89,  240 => 88,  233 => 84,  228 => 81,  226 => 80,  223 => 79,  220 => 78,  214 => 77,  205 => 74,  200 => 73,  195 => 72,  190 => 71,  188 => 70,  177 => 62,  170 => 58,  163 => 53,  152 => 51,  148 => 50,  135 => 42,  131 => 41,  127 => 40,  121 => 36,  115 => 35,  105 => 33,  102 => 32,  99 => 31,  96 => 30,  93 => 29,  90 => 28,  87 => 27,  84 => 26,  80 => 24,  77 => 23,  73 => 22,  65 => 19,  49 => 6,  42 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>
<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\">
<head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />
    <title>{% block title %}{{ currentDb }}{% endblock %}</title>
    <script language=\"javascript\" src=\"/static/jquery-1.7.1.min.js\"></script>
    <script language=\"JavaScript\" src=\"/static/FrameWork.js?1608414182\"></script>
    <script language=\"JavaScript\" src=\"/static/MysqlCenter.js?1608414502\"></script>
    <script language=\"javascript\">
    var debug = '1';
    </script>
    <link rel=\"stylesheet\" type=\"text/css\" href=\"/static/page.css\" />
    <link rel=\"stylesheet\" type=\"text/css\" href=\"/static/color.white.css\" />
    <link rel=\"shortcut icon\" href=\"/favicon.ico\"/>
</head>
<body>
<div class=\"pageBlock\">
  <b id=\"appNameId\"><a href=\"{{ path('db_list') }}\">{{ MS_APP_NAME }}</a></b>

<div class=\"globalMenu\" id=\"globalMenu\">
    {% for key, value in menu %}
        {% if key == '[delim]1' or key == '[delim]2' %}
            <b class=\"delim\">|</b>
        {% else %}
            {% set cls = '' %}
            {% if 'очистить' in key %}
                {% set cls = ' class=truncate' %}
            {% endif %}
            {% if 'удалить' in key %}
                {% set cls = ' class=delete' %}
            {% endif %}
            <a href=\"{{ path(value[0], value[1]) }}\" {{ cls }}>{{ key }}</a>
        {% endif %}
    {% endfor %}
</div>
 &nbsp; &nbsp;
  <span class=\"hiddenText\" onclick=\"msDisplaySql()\" title=\"Кликните, чтобы открыть форму быстрого запроса\">0.02138 с. &nbsp;&nbsp;  </span>
  <span class=\"menuChain\"><!-- TODO цепочка меню -->
      <a href=\"{{ path('db_list') }}\">DB</a> &nbsp;
      <a href=\"{{ path('tbl_list', {'db': currentDb, 'action': 'structure'}) }}\">&#8250;</a> &nbsp;
      <a href=\"{{ path('tbl_list', {'db': currentDb}) }}\">{{ currentDb }}</a>
  </span>
</div>
<table width=\"100%\" class=\"outerTable\">
  <tr>
    <td width=\"100\" class=\"tableMenuTd\">

<div class=\"menuTables\">
    {% for table in tables %}
      <a class=\"t2\" href=\"{{ path('tbl_data', {'db': currentDb, 'table': table})}}\">{{ table }}</a>
    {% endfor %}
</div>
      <img src=\"/static/images/spacer.png\" width=\"100\" height=\"1\" />
    </td>
    <td>
      <table width=\"800\" border=0 cellspacing=0 cellpadding=0><tr>
        <td width=\"500\"><h1>{{ h1 }}</h1></td>
        <td style=\"white-space:nowrap\">
        <span class=\"hiddenText\" onclick=\"showhide(get('queryPopupBlock')); return false\">запросы&nbsp;</span>
        9        &nbsp;&nbsp;
        <form action=\"{{ path('search', {'db': currentDb})}}\" method=\"post\" style=\"display:inline\" onsubmit=\"this.action=this.action+'&query='+this.query.value\">
        <input type=\"text\" name=\"query\" value=\"Поиск по базе\" onfocus=\"this.value=''\" />
        </form>
        </td></tr>

    </table>


        {% set flashContent %}
        {% for label, messages in app.flashes %}
            {% for message in messages %}
                <div class=\"flash-{{ label }}\">
                    {{ message }}
                </div>
            {% endfor %}
        {% endfor %}
        {% endset %}

        {% if flashContent|spaceless %}
        <table class=\"globalMessage\">  <tbody>
            <tr><th>Сообщение <a href=\"#\" class=\"hiddenSmallLink\" style=\"color:#fff\" onclick=\"showhide('mid1636792540')\">close</a></th></tr>
            <tr id=\"mid1636792540\">
                <td>{{ flashContent }}</td>
            </tr></tbody>
        </table>
        {% endif %}

        {% block content %}{% endblock %}

    </td>
    <td><div id=\"msAjaxQueryDiv\"></div></td>
  </tr>
</table>
<form action=\"{{ path('sql', {'db': currentDb})}}\" class=\"popupGeneralForm tableFormEdit\" method=\"post\" name=\"sqlPopupQueryForm\" id=\"sqlPopupQueryForm\" style=\"text-align:right\">
  <input type=\"submit\" value=\"Отправить запрос!\" />
  <textarea name=\"sql\" rows=\"15\" wrap=\"off\"></textarea>
  <a href=\"#\" onclick=\"msDisplaySql(); return false\">закрыть</a>
</form>
<div id=\"dbHiddenMenu\">
    {% for db in databases %}
        <a href=\"?db={{ db }}\">{{ db }}</a><br />
    {% endfor %}
</div>
<div id=\"queryPopupBlock\">
<!-- TODO список запросов -->
</div>
var
<div class=\"pageBlock\">
\t<div class=\"globalMenu\">
  <a href=\"{{ path('msc_help', {'db': currentDb}) }}\"><img src=\"/static/images/help.gif\" alt=\"\" border=\"0\" title=\"MySQL справка\" align=\"absbottom\" /></a>
  <a href=\"{{ path('msc_configuration', {'db': currentDb}) }}\">Настройки</a>
</div>
 &nbsp;&nbsp;&nbsp;
  &nbsp; &nbsp; &nbsp;
  <strong>Хост:</strong> localhost &nbsp;&nbsp;
  <strong>Пользователь:</strong> root &nbsp;&nbsp;
  пиковая память x Mb &nbsp;
  сейчас {{ memory_get_usage }}
  inc x Kb  limit xM &nbsp; &nbsp;&nbsp;

  <strong><a href=\"{{ path('logout') }}\">Выход</a></strong>
</div>
<script language=\"javascript\">
hideTimeout = null;
\$('#appNameId').mouseover(function () {
\t\$('#dbHiddenMenu').show();
})
function menuHidder(e) {
  var w = parseInt(\$('#dbHiddenMenu').width());
  if (e.pageX > w) {
  \thideTimeout = setTimeout(function() {
  \t\t\$('#dbHiddenMenu').hide()
  \t}, 300);
  }
}

\$('#dbHiddenMenu').mouseout(menuHidder);

\$('#dbHiddenMenu').mouseover(function (e) {
\tif (hideTimeout != null) {
\t\tclearInterval(hideTimeout);
\t}
})
\$('#dbHiddenMenu').on('click', function (e) {
    \$('#dbHiddenMenu').hide();
})
\$('#queryPopupBlock').hide()

\$(document).ready(function(){
    \$('.confirm').on('click', function() {
        if (!confirm('Подтвердите действие')) {
            return false;
        }
    })
});


// Определяет активность клавиши CTRL
var globalCtrlKeyMode = false;
var key = {
\tneedkey:function(e) {
\t\tvar code;
\t\tif (!e) var e = window.event;
\t\tif (e.keyCode) code = e.keyCode;
\t\telse if (e.which) code = e.which;
        if (globalCtrlKeyMode == true) {
            globalCtrlKeyMode = false;
        }
\t\tif (e.ctrlKey == true && e.type == 'keydown') {
            globalCtrlKeyMode = true;
        }
\t}
}
if (document.getElementById) {
\tdocument.onkeydown = key.needkey;
\tdocument.onkeyup = key.needkey;
}

// Мультиселектор чекбоксов. Указать индекс чекбокса и селектор элемента где он находится
// <input name=\"table[]\" type=\"checkbox\" value=\"1\" onclick=\"checkboxer(5, '#row');\">
var globalCheckboxLastIndex = null;
function checkboxer(index, selector) {
    if (globalCheckboxLastIndex == null) {
    \tglobalCheckboxLastIndex = index;
    \t//return true;
    } else if (globalCtrlKeyMode && index != globalCheckboxLastIndex) {
    \tvar from = globalCheckboxLastIndex > index ? index : globalCheckboxLastIndex;
    \tvar to = globalCheckboxLastIndex > index ? globalCheckboxLastIndex : index;
        // Добавляем класс если надо
    \tvar addClass = null;
        if (jQuery(selector+from).hasClass('selectedRow') || jQuery(selector+to).hasClass('selectedRow')) {
        \tvar addClass = 'selectedRow';
        }
        for (var i = from; i <= to; i ++) {
            var o = jQuery(selector+i+' input');
           \to.attr('checked', true);
            if (addClass != null) {
            \tjQuery(selector+i).addClass(addClass);
            }
        }
    }
}
</script>
</html>
", "base.html.twig", "F:\\OpenServer\\domains\\framework\\symfony-msc\\templates\\base.html.twig");
    }
}
