<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* db_list.html.twig */
class __TwigTemplate_a07b14daa7084b157f100e6b40ba209e822f71d4f0e73c7b46123f8495e621f9 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "db_list.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "db_list.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    Список баз данных
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 7
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 8
        echo "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\">
    <tr>
        <td valign=\"top\">
            <form action=\"";
        // line 11
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("db_list");
        echo "\" method=\"post\" name=\"formDatabases\" id=\"formDatabases\">
                <input type=\"hidden\" name=\"dbMulty\" value=\"1\" />
                <input type=\"hidden\" name=\"action\" value=\"\" />
                <table class=\"contentTable\" id=\"structureTableId\">
                    <thead>
                    <tr>
                        <th>&nbsp;</th>
                        <th>Название</th>
                        <th>&nbsp;</th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 23
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 23, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 24
            echo "                    <tr>
                        <td><input name=\"databases[]\" type=\"checkbox\" value=\"bitrix\" class=\"cb\"></td>
                        <td><a href=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("tbl_list", ["db" => $context["item"]]), "html", null, true);
            echo "\" title=\"Структура БД\" id=\"dbbitrix\">";
            echo twig_escape_filter($this->env, $context["item"], "html", null, true);
            echo "</a></td>
                        <td>
                            <a href=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("db_list", ["db" => $context["item"], "action" => "dbDelete"]), "html", null, true);
            echo "\" class=\"confirm\" title=\"Удалить ";
            echo twig_escape_filter($this->env, $context["item"], "html", null, true);
            echo "\">
                                <img src=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("static/images/close.png"), "html", null, true);
            echo "\" alt=\"\" border=\"0\" />
                            </a>
                            <a href=\"?db=bitrix&s=actions\" title=\"Изменить\"><img src=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("static/images/edit.gif"), "html", null, true);
            echo "\" alt=\"\" border=\"0\" /></a>
                            <a href=\"#\" onclick=\"msQuery('dbHide', 'db=bitrix&id=dbbitrix'); return false\" title=\"Спрятать/показать bitrix\">
                                <img src=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("static/images/open-folder.png"), "html", null, true);
            echo "\" alt=\"\" border=\"0\" width=16 />
                            </a>
                        </td>
                    </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 38
        echo "                    </tbody>
                </table>
            </form>
            <div class=\"chbxAction\">
                <img src=\"";
        // line 42
        echo twig_escape_filter($this->env, (isset($context["MS_DIR_IMG"]) || array_key_exists("MS_DIR_IMG", $context) ? $context["MS_DIR_IMG"] : (function () { throw new RuntimeError('Variable "MS_DIR_IMG" does not exist.', 42, $this->source); })()), "html", null, true);
        echo "arrow_ltr.png\" alt=\"\" border=\"0\" align=\"absmiddle\" />
                <a href=\"#\" onClick=\"chbx_action('formDatabases', 'check', 'databases[]'); return false\">выбрать все</a>  &nbsp;
                <a href=\"#\" onClick=\"chbx_action('formDatabases', 'uncheck', 'databases[]'); return false\">очистить</a>
            </div>
        </td>
        <td valign=\"top\">
            <fieldset class=\"msGeneralForm\">
                <legend>Создание базы данных</legend>
                <form action=\"";
        // line 50
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("db_list", ["action" => "dbCreate"]);
        echo "\" method=\"post\">
                    <input name=\"dbName\" type=\"text\" value=\"\" />
                    <input type=\"submit\" value=\"Создать!\">
                </form>
            </fieldset>

            ";
        // line 56
        if ((isset($context["showFullInfo"]) || array_key_exists("showFullInfo", $context) ? $context["showFullInfo"] : (function () { throw new RuntimeError('Variable "showFullInfo" does not exist.', 56, $this->source); })())) {
            // line 57
            echo "                <a href=\"";
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("db_list", ["mode" => "full"]);
            echo "\" title=\"Сканирует все таблицы всех баз данных и выводит количество таблиц, размер, дату обновления и количество рядов\">Показать полную таблицу</a>
            ";
        } else {
            // line 59
            echo "                <a href=\"";
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("db_list");
            echo "\">Показать краткую таблицу</a>
            ";
        }
        // line 61
        echo "
            <br><a href=\"";
        // line 62
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("db_list", ["mode" => "speedtest"]);
        echo "\">Тест скорости</a>
            <br />
            <br />
            <br />
            ";
        // line 66
        echo twig_escape_filter($this->env, (isset($context["MS_APP_NAME"]) || array_key_exists("MS_APP_NAME", $context) ? $context["MS_APP_NAME"] : (function () { throw new RuntimeError('Variable "MS_APP_NAME" does not exist.', 66, $this->source); })()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["MS_APP_VERSION"]) || array_key_exists("MS_APP_VERSION", $context) ? $context["MS_APP_VERSION"] : (function () { throw new RuntimeError('Variable "MS_APP_VERSION" does not exist.', 66, $this->source); })()), "html", null, true);
        echo " <br />
            Хост: ";
        // line 67
        echo twig_escape_filter($this->env, (isset($context["mysqlhost"]) || array_key_exists("mysqlhost", $context) ? $context["mysqlhost"] : (function () { throw new RuntimeError('Variable "mysqlhost" does not exist.', 67, $this->source); })()), "html", null, true);
        echo "<br /><br />
            Версия сервера: ";
        // line 68
        echo twig_escape_filter($this->env, (isset($context["mysqlversion"]) || array_key_exists("mysqlversion", $context) ? $context["mysqlversion"] : (function () { throw new RuntimeError('Variable "mysqlversion" does not exist.', 68, $this->source); })()), "html", null, true);
        echo "<br />
            Версия PHP: ";
        // line 69
        echo twig_escape_filter($this->env, (isset($context["phpversion"]) || array_key_exists("phpversion", $context) ? $context["phpversion"] : (function () { throw new RuntimeError('Variable "phpversion" does not exist.', 69, $this->source); })()), "html", null, true);
        echo "
            ";
        // line 70
        (((isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 70, $this->source); })())) ? (print (twig_escape_filter($this->env, ("<br />БД: " + (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 70, $this->source); })())), "html", null, true))) : (print ("")));
        echo "<br />

            <fieldset class=\"msGeneralForm\">
                <legend>Добавить пользователя</legend>
                <form action=\"";
        // line 74
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("users", ["action" => "add"]);
        echo "\" method=\"post\">
                    <div style=\"margin-bottom:5px\"><input name=\"rootpass\" type=\"text\" value=\"\" /> Пароль админа</div>
                    <div style=\"margin-bottom:5px\"><input name=\"database\" type=\"text\" required id=\"databaseField\" onkeyup=\"jQuery('#unameField').val(this.value)\" /> Имя базы данных</div>
                    <div style=\"margin-bottom:5px\"><input name=\"databaseuser\" id=\"unameField\" type=\"text\" required /> Логин пользователя</div>
                    <div style=\"margin-bottom:5px\"><input name=\"userpass\" type=\"password\" id=\"passwordField\" required /> Пароль</div>
                    <div style=\"margin-bottom:5px\"><input name=\"userpass2\" type=\"password\" id=\"password2Field\" required /> Пароль еще раз</div>
                    <div><input type=\"submit\" value=\"Добавить\" disabled=\"true\" id=\"submitBtnId\" /></div>
                </form>
            </fieldset>

            <script language=\"javascript\">
                function updateButton() {
                    var doEnable = true;
                    if (jQuery('#passwordField').val() != jQuery('#password2Field').val()) {
                        doEnable = false;
                    }
                    if (doEnable) {
                        document.querySelector('#submitBtnId').disabled = false;
                    }
                }
                jQuery(document).ready(function(){
                    jQuery('form input').on('keyup', updateButton)
                });
            </script>

        </td>
    </tr>
</table>

<div class=\"imageAction\">
    <u>Выбранные</u>
    <input type=\"image\" src=\"";
        // line 105
        echo twig_escape_filter($this->env, (isset($context["MS_DIR_IMG"]) || array_key_exists("MS_DIR_IMG", $context) ? $context["MS_DIR_IMG"] : (function () { throw new RuntimeError('Variable "MS_DIR_IMG" does not exist.', 105, $this->source); })()), "html", null, true);
        echo "close.png\" title=\"Удалить базы данных\" onClick=\"msImageAction('formDatabases', 'dbDelete'); return false\" />
    <input type=\"image\" src=\"";
        // line 106
        echo twig_escape_filter($this->env, (isset($context["MS_DIR_IMG"]) || array_key_exists("MS_DIR_IMG", $context) ? $context["MS_DIR_IMG"] : (function () { throw new RuntimeError('Variable "MS_DIR_IMG" does not exist.', 106, $this->source); })()), "html", null, true);
        echo "copy.gif\" title=\"Скопировать базы данных по шаблону {db_name}_copy\" onClick=\"msImageAction('formDatabases', 'dbCopy'); return false\" />
    <input type=\"image\" src=\"";
        // line 107
        echo twig_escape_filter($this->env, (isset($context["MS_DIR_IMG"]) || array_key_exists("MS_DIR_IMG", $context) ? $context["MS_DIR_IMG"] : (function () { throw new RuntimeError('Variable "MS_DIR_IMG" does not exist.', 107, $this->source); })()), "html", null, true);
        echo "b_tblexport.png\" title=\"Перейти к экспорту баз данных\" onClick=\"msImageAction('formDatabases', 'exportDatabases', '<?php echo MS_URL?>?s=export'); return false\" />
    <input type=\"image\" src=\"";
        // line 108
        echo twig_escape_filter($this->env, (isset($context["MS_DIR_IMG"]) || array_key_exists("MS_DIR_IMG", $context) ? $context["MS_DIR_IMG"] : (function () { throw new RuntimeError('Variable "MS_DIR_IMG" does not exist.', 108, $this->source); })()), "html", null, true);
        echo "fixed.gif\" title=\"Сравнить выбранные базы данных\" onClick=\"msImageAction('formDatabases', '', '<?php echo MS_URL?>?s=db_compare'); return false\" />
</div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "db_list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  258 => 108,  254 => 107,  250 => 106,  246 => 105,  212 => 74,  205 => 70,  201 => 69,  197 => 68,  193 => 67,  187 => 66,  180 => 62,  177 => 61,  171 => 59,  165 => 57,  163 => 56,  154 => 50,  143 => 42,  137 => 38,  126 => 33,  121 => 31,  116 => 29,  110 => 28,  103 => 26,  99 => 24,  95 => 23,  80 => 11,  75 => 8,  68 => 7,  60 => 4,  53 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}
    Список баз данных
{% endblock %}

{% block content %}
<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\">
    <tr>
        <td valign=\"top\">
            <form action=\"{{ path('db_list') }}\" method=\"post\" name=\"formDatabases\" id=\"formDatabases\">
                <input type=\"hidden\" name=\"dbMulty\" value=\"1\" />
                <input type=\"hidden\" name=\"action\" value=\"\" />
                <table class=\"contentTable\" id=\"structureTableId\">
                    <thead>
                    <tr>
                        <th>&nbsp;</th>
                        <th>Название</th>
                        <th>&nbsp;</th>
                    </tr>
                    </thead>
                    <tbody>
                    {% for item in data %}
                    <tr>
                        <td><input name=\"databases[]\" type=\"checkbox\" value=\"bitrix\" class=\"cb\"></td>
                        <td><a href=\"{{ path('tbl_list', {'db': item} ) }}\" title=\"Структура БД\" id=\"dbbitrix\">{{ item }}</a></td>
                        <td>
                            <a href=\"{{ path('db_list', {'db': item, 'action': 'dbDelete'}) }}\" class=\"confirm\" title=\"Удалить {{ item }}\">
                                <img src=\"{{ asset('static/images/close.png') }}\" alt=\"\" border=\"0\" />
                            </a>
                            <a href=\"?db=bitrix&s=actions\" title=\"Изменить\"><img src=\"{{ asset('static/images/edit.gif') }}\" alt=\"\" border=\"0\" /></a>
                            <a href=\"#\" onclick=\"msQuery('dbHide', 'db=bitrix&id=dbbitrix'); return false\" title=\"Спрятать/показать bitrix\">
                                <img src=\"{{ asset('static/images/open-folder.png') }}\" alt=\"\" border=\"0\" width=16 />
                            </a>
                        </td>
                    </tr>
                    {% endfor %}
                    </tbody>
                </table>
            </form>
            <div class=\"chbxAction\">
                <img src=\"{{ MS_DIR_IMG }}arrow_ltr.png\" alt=\"\" border=\"0\" align=\"absmiddle\" />
                <a href=\"#\" onClick=\"chbx_action('formDatabases', 'check', 'databases[]'); return false\">выбрать все</a>  &nbsp;
                <a href=\"#\" onClick=\"chbx_action('formDatabases', 'uncheck', 'databases[]'); return false\">очистить</a>
            </div>
        </td>
        <td valign=\"top\">
            <fieldset class=\"msGeneralForm\">
                <legend>Создание базы данных</legend>
                <form action=\"{{ path('db_list', {'action': 'dbCreate'}) }}\" method=\"post\">
                    <input name=\"dbName\" type=\"text\" value=\"\" />
                    <input type=\"submit\" value=\"Создать!\">
                </form>
            </fieldset>

            {% if showFullInfo %}
                <a href=\"{{ path('db_list', {'mode': 'full'}) }}\" title=\"Сканирует все таблицы всех баз данных и выводит количество таблиц, размер, дату обновления и количество рядов\">Показать полную таблицу</a>
            {% else %}
                <a href=\"{{ path('db_list') }}\">Показать краткую таблицу</a>
            {% endif %}

            <br><a href=\"{{ path('db_list', {'mode': 'speedtest'}) }}\">Тест скорости</a>
            <br />
            <br />
            <br />
            {{ MS_APP_NAME }} {{ MS_APP_VERSION }} <br />
            Хост: {{ mysqlhost }}<br /><br />
            Версия сервера: {{ mysqlversion }}<br />
            Версия PHP: {{ phpversion }}
            {{ currentDb ? '<br />БД: '+currentDb : '' }}<br />

            <fieldset class=\"msGeneralForm\">
                <legend>Добавить пользователя</legend>
                <form action=\"{{ path('users', {'action': 'add'}) }}\" method=\"post\">
                    <div style=\"margin-bottom:5px\"><input name=\"rootpass\" type=\"text\" value=\"\" /> Пароль админа</div>
                    <div style=\"margin-bottom:5px\"><input name=\"database\" type=\"text\" required id=\"databaseField\" onkeyup=\"jQuery('#unameField').val(this.value)\" /> Имя базы данных</div>
                    <div style=\"margin-bottom:5px\"><input name=\"databaseuser\" id=\"unameField\" type=\"text\" required /> Логин пользователя</div>
                    <div style=\"margin-bottom:5px\"><input name=\"userpass\" type=\"password\" id=\"passwordField\" required /> Пароль</div>
                    <div style=\"margin-bottom:5px\"><input name=\"userpass2\" type=\"password\" id=\"password2Field\" required /> Пароль еще раз</div>
                    <div><input type=\"submit\" value=\"Добавить\" disabled=\"true\" id=\"submitBtnId\" /></div>
                </form>
            </fieldset>

            <script language=\"javascript\">
                function updateButton() {
                    var doEnable = true;
                    if (jQuery('#passwordField').val() != jQuery('#password2Field').val()) {
                        doEnable = false;
                    }
                    if (doEnable) {
                        document.querySelector('#submitBtnId').disabled = false;
                    }
                }
                jQuery(document).ready(function(){
                    jQuery('form input').on('keyup', updateButton)
                });
            </script>

        </td>
    </tr>
</table>

<div class=\"imageAction\">
    <u>Выбранные</u>
    <input type=\"image\" src=\"{{ MS_DIR_IMG }}close.png\" title=\"Удалить базы данных\" onClick=\"msImageAction('formDatabases', 'dbDelete'); return false\" />
    <input type=\"image\" src=\"{{ MS_DIR_IMG }}copy.gif\" title=\"Скопировать базы данных по шаблону {db_name}_copy\" onClick=\"msImageAction('formDatabases', 'dbCopy'); return false\" />
    <input type=\"image\" src=\"{{ MS_DIR_IMG }}b_tblexport.png\" title=\"Перейти к экспорту баз данных\" onClick=\"msImageAction('formDatabases', 'exportDatabases', '<?php echo MS_URL?>?s=export'); return false\" />
    <input type=\"image\" src=\"{{ MS_DIR_IMG }}fixed.gif\" title=\"Сравнить выбранные базы данных\" onClick=\"msImageAction('formDatabases', '', '<?php echo MS_URL?>?s=db_compare'); return false\" />
</div>

{% endblock %}", "db_list.html.twig", "F:\\OpenServer\\domains\\framework\\symfony-msc\\templates\\db_list.html.twig");
    }
}
