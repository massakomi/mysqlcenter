<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_12608c1d97239c14b60cceb0954fa0cde87b2d7c4766e2347e2022e208f663ff extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>
<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\">
<head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />
    <title>";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    <script language=\"javascript\" src=\"/static/jquery-1.7.1.min.js\"></script>
    <script language=\"JavaScript\" src=\"/static/MysqlCenter.js\"></script>
    <script language=\"javascript\">
    var debug = '1';
    </script>
    <link rel=\"stylesheet\" type=\"text/css\" href=\"/static/page.css\" />
    <link rel=\"stylesheet\" type=\"text/css\" href=\"/static/color.white.css\" />
    <link rel=\"shortcut icon\" href=\"/favicon.ico\"/>
</head>
<body>
<div class=\"pageBlock\">
  <b id=\"appNameId\"><a href=\"";
        // line 18
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("db_list");
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["MS_APP_NAME"]) || array_key_exists("MS_APP_NAME", $context) ? $context["MS_APP_NAME"] : (function () { throw new RuntimeError('Variable "MS_APP_NAME" does not exist.', 18, $this->source); })()), "html", null, true);
        echo "</a></b>

<div class=\"globalMenu\" id=\"globalMenu\">
    ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["menu"]) || array_key_exists("menu", $context) ? $context["menu"] : (function () { throw new RuntimeError('Variable "menu" does not exist.', 21, $this->source); })()));
        foreach ($context['_seq'] as $context["key"] => $context["value"]) {
            // line 22
            echo "        ";
            if (((0 === twig_compare($context["key"], "[delim]1")) || (0 === twig_compare($context["key"], "[delim]2")))) {
                // line 23
                echo "            <b class=\"delim\">|</b>
        ";
            } else {
                // line 25
                echo "            ";
                $context["cls"] = "";
                // line 26
                echo "            ";
                if (twig_in_filter("очистить", $context["key"])) {
                    // line 27
                    echo "                ";
                    $context["cls"] = " class=truncate";
                    // line 28
                    echo "            ";
                }
                // line 29
                echo "            ";
                if (twig_in_filter("удалить", $context["key"])) {
                    // line 30
                    echo "                ";
                    $context["cls"] = " class=delete";
                    // line 31
                    echo "            ";
                }
                // line 32
                echo "            <a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(twig_get_attribute($this->env, $this->source, $context["value"], 0, [], "array", false, false, false, 32), twig_get_attribute($this->env, $this->source, $context["value"], 1, [], "array", false, false, false, 32)), "html", null, true);
                echo "\" ";
                echo twig_escape_filter($this->env, (isset($context["cls"]) || array_key_exists("cls", $context) ? $context["cls"] : (function () { throw new RuntimeError('Variable "cls" does not exist.', 32, $this->source); })()), "html", null, true);
                echo ">";
                echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                echo "</a>
        ";
            }
            // line 34
            echo "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['value'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "</div>
 &nbsp; &nbsp;
  <span class=\"hiddenText\" onclick=\"msDisplaySql()\" title=\"Кликните, чтобы открыть форму быстрого запроса\">0.02138 с. &nbsp;&nbsp;  </span>
  <span class=\"menuChain\"><!-- TODO цепочка меню -->
      <a href=\"";
        // line 39
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("db_list");
        echo "\">DB</a> &nbsp;
      <a href=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("tbl_list", ["db" => (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 40, $this->source); })()), "action" => "structure"]), "html", null, true);
        echo "\">&#8250;</a> &nbsp;
      <a href=\"";
        // line 41
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("tbl_list", ["db" => (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 41, $this->source); })())]), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 41, $this->source); })()), "html", null, true);
        echo "</a>
  </span>
</div>
<table width=\"100%\" class=\"outerTable\">
  <tr>
    <td width=\"100\" class=\"tableMenuTd\">

<div class=\"menuTables\">
    ";
        // line 49
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["tables"]) || array_key_exists("tables", $context) ? $context["tables"] : (function () { throw new RuntimeError('Variable "tables" does not exist.', 49, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["table"]) {
            // line 50
            echo "      <a class=\"t2\" href=\"";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("tbl_data", ["db" => (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 50, $this->source); })()), "table" => $context["table"]]), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $context["table"], "html", null, true);
            echo "</a>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['table'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 52
        echo "</div>
      <img src=\"/static/images/spacer.png\" width=\"100\" height=\"1\" />
    </td>
    <td>
      <table width=\"800\" border=0 cellspacing=0 cellpadding=0><tr>
        <td width=\"500\"><h1>";
        // line 57
        echo twig_escape_filter($this->env, (isset($context["h1"]) || array_key_exists("h1", $context) ? $context["h1"] : (function () { throw new RuntimeError('Variable "h1" does not exist.', 57, $this->source); })()), "html", null, true);
        echo "</h1></td>
        <td style=\"white-space:nowrap\">
        <span class=\"hiddenText\" onclick=\"showhide(get('queryPopupBlock')); return false\">запросы&nbsp;</span>
        9        &nbsp;&nbsp;
        <form action=\"";
        // line 61
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("search", ["db" => (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 61, $this->source); })())]), "html", null, true);
        echo "\" method=\"post\" style=\"display:inline\" onsubmit=\"this.action=this.action+'&query='+this.query.value\">
        <input type=\"text\" name=\"query\" value=\"Поиск по базе\" onfocus=\"this.value=''\" />
        </form>
        </td></tr>

    </table>


        ";
        // line 69
        ob_start();
        // line 70
        echo "        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 70, $this->source); })()), "flashes", [], "any", false, false, false, 70));
        foreach ($context['_seq'] as $context["label"] => $context["messages"]) {
            // line 71
            echo "            ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["messages"]);
            foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                // line 72
                echo "                <div class=\"flash-";
                echo twig_escape_filter($this->env, $context["label"], "html", null, true);
                echo "\">
                    ";
                // line 73
                echo twig_escape_filter($this->env, $context["message"], "html", null, true);
                echo "
                </div>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 76
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['label'], $context['messages'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 77
        echo "        ";
        $context["flashContent"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 78
        echo "
        ";
        // line 79
        if (twig_spaceless((isset($context["flashContent"]) || array_key_exists("flashContent", $context) ? $context["flashContent"] : (function () { throw new RuntimeError('Variable "flashContent" does not exist.', 79, $this->source); })()))) {
            // line 80
            echo "        <table class=\"globalMessage\">  <tbody>
            <tr><th>Сообщение <a href=\"#\" class=\"hiddenSmallLink\" style=\"color:#fff\" onclick=\"showhide('mid1636792540')\">close</a></th></tr>
            <tr id=\"mid1636792540\">
                <td>";
            // line 83
            echo twig_escape_filter($this->env, (isset($context["flashContent"]) || array_key_exists("flashContent", $context) ? $context["flashContent"] : (function () { throw new RuntimeError('Variable "flashContent" does not exist.', 83, $this->source); })()), "html", null, true);
            echo "</td>
            </tr></tbody>
        </table>
        ";
        }
        // line 87
        echo "
        ";
        // line 88
        $this->displayBlock('content', $context, $blocks);
        // line 89
        echo "
    </td>
    <td><div id=\"msAjaxQueryDiv\"></div></td>
  </tr>
</table>
<form action=\"";
        // line 94
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("sql", ["db" => (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 94, $this->source); })())]), "html", null, true);
        echo "\" class=\"popupGeneralForm tableFormEdit\" method=\"post\" name=\"sqlPopupQueryForm\" id=\"sqlPopupQueryForm\" style=\"text-align:right\">
  <input type=\"submit\" value=\"Отправить запрос!\" />
  <textarea name=\"sql\" rows=\"15\" wrap=\"off\"></textarea>
  <a href=\"#\" onclick=\"msDisplaySql(); return false\">закрыть</a>
</form>
<div id=\"dbHiddenMenu\">
    ";
        // line 100
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["databases"]) || array_key_exists("databases", $context) ? $context["databases"] : (function () { throw new RuntimeError('Variable "databases" does not exist.', 100, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["db"]) {
            // line 101
            echo "        <a href=\"?db=";
            echo twig_escape_filter($this->env, $context["db"], "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $context["db"], "html", null, true);
            echo "</a><br />
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['db'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 103
        echo "</div>
<div id=\"queryPopupBlock\">
<!-- TODO список запросов -->
</div>

<div class=\"pageBlock\">
\t<div class=\"globalMenu\">
  <a href=\"";
        // line 110
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("msc_help", ["db" => (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 110, $this->source); })())]), "html", null, true);
        echo "\"><img src=\"/static/images/help.gif\" alt=\"\" border=\"0\" title=\"MySQL справка\" align=\"absbottom\" /></a>
  <a href=\"";
        // line 111
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("msc_configuration", ["db" => (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 111, $this->source); })())]), "html", null, true);
        echo "\">Настройки</a>
</div>
 &nbsp;&nbsp;&nbsp;
  &nbsp; &nbsp; &nbsp;
  <strong>Хост:</strong> ";
        // line 115
        echo twig_escape_filter($this->env, (isset($context["mysqlhost"]) || array_key_exists("mysqlhost", $context) ? $context["mysqlhost"] : (function () { throw new RuntimeError('Variable "mysqlhost" does not exist.', 115, $this->source); })()), "html", null, true);
        echo " &nbsp;&nbsp;
  <strong>Пользователь:</strong> ";
        // line 116
        echo twig_escape_filter($this->env, (isset($context["mysqluser"]) || array_key_exists("mysqluser", $context) ? $context["mysqluser"] : (function () { throw new RuntimeError('Variable "mysqluser" does not exist.', 116, $this->source); })()), "html", null, true);
        echo " &nbsp;&nbsp;
  пиковая память ";
        // line 117
        echo twig_escape_filter($this->env, $this->extensions['App\Twig\AppExtension']->formatSize((isset($context["memory_get_peak_usage"]) || array_key_exists("memory_get_peak_usage", $context) ? $context["memory_get_peak_usage"] : (function () { throw new RuntimeError('Variable "memory_get_peak_usage" does not exist.', 117, $this->source); })())), "html", null, true);
        echo " &nbsp;
  сейчас ";
        // line 118
        echo twig_escape_filter($this->env, $this->extensions['App\Twig\AppExtension']->formatSize((isset($context["memory_get_usage"]) || array_key_exists("memory_get_usage", $context) ? $context["memory_get_usage"] : (function () { throw new RuntimeError('Variable "memory_get_usage" does not exist.', 118, $this->source); })())), "html", null, true);
        echo "
  inc ";
        // line 119
        echo twig_escape_filter($this->env, $this->extensions['App\Twig\AppExtension']->formatSize((isset($context["includes_size"]) || array_key_exists("includes_size", $context) ? $context["includes_size"] : (function () { throw new RuntimeError('Variable "includes_size" does not exist.', 119, $this->source); })())), "html", null, true);
        echo "
    limit ";
        // line 120
        echo twig_escape_filter($this->env, (isset($context["memory_limit"]) || array_key_exists("memory_limit", $context) ? $context["memory_limit"] : (function () { throw new RuntimeError('Variable "memory_limit" does not exist.', 120, $this->source); })()), "html", null, true);
        echo " &nbsp; &nbsp;&nbsp;

  <strong><a href=\"";
        // line 122
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("logout");
        echo "\">Выход</a></strong>
</div>

</html>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 6
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 6, $this->source); })()), "html", null, true);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 88
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  345 => 88,  332 => 6,  320 => 122,  315 => 120,  311 => 119,  307 => 118,  303 => 117,  299 => 116,  295 => 115,  288 => 111,  284 => 110,  275 => 103,  264 => 101,  260 => 100,  251 => 94,  244 => 89,  242 => 88,  239 => 87,  232 => 83,  227 => 80,  225 => 79,  222 => 78,  219 => 77,  213 => 76,  204 => 73,  199 => 72,  194 => 71,  189 => 70,  187 => 69,  176 => 61,  169 => 57,  162 => 52,  151 => 50,  147 => 49,  134 => 41,  130 => 40,  126 => 39,  120 => 35,  114 => 34,  104 => 32,  101 => 31,  98 => 30,  95 => 29,  92 => 28,  89 => 27,  86 => 26,  83 => 25,  79 => 23,  76 => 22,  72 => 21,  64 => 18,  49 => 6,  42 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>
<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\">
<head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />
    <title>{% block title %}{{ currentDb }}{% endblock %}</title>
    <script language=\"javascript\" src=\"/static/jquery-1.7.1.min.js\"></script>
    <script language=\"JavaScript\" src=\"/static/MysqlCenter.js\"></script>
    <script language=\"javascript\">
    var debug = '1';
    </script>
    <link rel=\"stylesheet\" type=\"text/css\" href=\"/static/page.css\" />
    <link rel=\"stylesheet\" type=\"text/css\" href=\"/static/color.white.css\" />
    <link rel=\"shortcut icon\" href=\"/favicon.ico\"/>
</head>
<body>
<div class=\"pageBlock\">
  <b id=\"appNameId\"><a href=\"{{ path('db_list') }}\">{{ MS_APP_NAME }}</a></b>

<div class=\"globalMenu\" id=\"globalMenu\">
    {% for key, value in menu %}
        {% if key == '[delim]1' or key == '[delim]2' %}
            <b class=\"delim\">|</b>
        {% else %}
            {% set cls = '' %}
            {% if 'очистить' in key %}
                {% set cls = ' class=truncate' %}
            {% endif %}
            {% if 'удалить' in key %}
                {% set cls = ' class=delete' %}
            {% endif %}
            <a href=\"{{ path(value[0], value[1]) }}\" {{ cls }}>{{ key }}</a>
        {% endif %}
    {% endfor %}
</div>
 &nbsp; &nbsp;
  <span class=\"hiddenText\" onclick=\"msDisplaySql()\" title=\"Кликните, чтобы открыть форму быстрого запроса\">0.02138 с. &nbsp;&nbsp;  </span>
  <span class=\"menuChain\"><!-- TODO цепочка меню -->
      <a href=\"{{ path('db_list') }}\">DB</a> &nbsp;
      <a href=\"{{ path('tbl_list', {'db': currentDb, 'action': 'structure'}) }}\">&#8250;</a> &nbsp;
      <a href=\"{{ path('tbl_list', {'db': currentDb}) }}\">{{ currentDb }}</a>
  </span>
</div>
<table width=\"100%\" class=\"outerTable\">
  <tr>
    <td width=\"100\" class=\"tableMenuTd\">

<div class=\"menuTables\">
    {% for table in tables %}
      <a class=\"t2\" href=\"{{ path('tbl_data', {'db': currentDb, 'table': table})}}\">{{ table }}</a>
    {% endfor %}
</div>
      <img src=\"/static/images/spacer.png\" width=\"100\" height=\"1\" />
    </td>
    <td>
      <table width=\"800\" border=0 cellspacing=0 cellpadding=0><tr>
        <td width=\"500\"><h1>{{ h1 }}</h1></td>
        <td style=\"white-space:nowrap\">
        <span class=\"hiddenText\" onclick=\"showhide(get('queryPopupBlock')); return false\">запросы&nbsp;</span>
        9        &nbsp;&nbsp;
        <form action=\"{{ path('search', {'db': currentDb})}}\" method=\"post\" style=\"display:inline\" onsubmit=\"this.action=this.action+'&query='+this.query.value\">
        <input type=\"text\" name=\"query\" value=\"Поиск по базе\" onfocus=\"this.value=''\" />
        </form>
        </td></tr>

    </table>


        {% set flashContent %}
        {% for label, messages in app.flashes %}
            {% for message in messages %}
                <div class=\"flash-{{ label }}\">
                    {{ message }}
                </div>
            {% endfor %}
        {% endfor %}
        {% endset %}

        {% if flashContent|spaceless %}
        <table class=\"globalMessage\">  <tbody>
            <tr><th>Сообщение <a href=\"#\" class=\"hiddenSmallLink\" style=\"color:#fff\" onclick=\"showhide('mid1636792540')\">close</a></th></tr>
            <tr id=\"mid1636792540\">
                <td>{{ flashContent }}</td>
            </tr></tbody>
        </table>
        {% endif %}

        {% block content %}{% endblock %}

    </td>
    <td><div id=\"msAjaxQueryDiv\"></div></td>
  </tr>
</table>
<form action=\"{{ path('sql', {'db': currentDb})}}\" class=\"popupGeneralForm tableFormEdit\" method=\"post\" name=\"sqlPopupQueryForm\" id=\"sqlPopupQueryForm\" style=\"text-align:right\">
  <input type=\"submit\" value=\"Отправить запрос!\" />
  <textarea name=\"sql\" rows=\"15\" wrap=\"off\"></textarea>
  <a href=\"#\" onclick=\"msDisplaySql(); return false\">закрыть</a>
</form>
<div id=\"dbHiddenMenu\">
    {% for db in databases %}
        <a href=\"?db={{ db }}\">{{ db }}</a><br />
    {% endfor %}
</div>
<div id=\"queryPopupBlock\">
<!-- TODO список запросов -->
</div>

<div class=\"pageBlock\">
\t<div class=\"globalMenu\">
  <a href=\"{{ path('msc_help', {'db': currentDb}) }}\"><img src=\"/static/images/help.gif\" alt=\"\" border=\"0\" title=\"MySQL справка\" align=\"absbottom\" /></a>
  <a href=\"{{ path('msc_configuration', {'db': currentDb}) }}\">Настройки</a>
</div>
 &nbsp;&nbsp;&nbsp;
  &nbsp; &nbsp; &nbsp;
  <strong>Хост:</strong> {{ mysqlhost }} &nbsp;&nbsp;
  <strong>Пользователь:</strong> {{ mysqluser }} &nbsp;&nbsp;
  пиковая память {{ memory_get_peak_usage|formatSize }} &nbsp;
  сейчас {{ memory_get_usage|formatSize }}
  inc {{ includes_size|formatSize }}
    limit {{ memory_limit }} &nbsp; &nbsp;&nbsp;

  <strong><a href=\"{{ path('logout') }}\">Выход</a></strong>
</div>

</html>
", "base.html.twig", "F:\\OpenServer\\domains\\framework\\symfony-msc\\templates\\base.html.twig");
    }
}
