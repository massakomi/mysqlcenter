<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* tbl_list.html.twig */
class __TwigTemplate_ebf5c939d9aeeb8dbe0f7ee2fb00cd4b2053537c6cc5b5cb42966d7c974b2e0c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "tbl_list.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "tbl_list.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    Список таблиц ";
        echo twig_escape_filter($this->env, (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 4, $this->source); })()), "html", null, true);
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 7
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 8
        echo "    ";
        if ((isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 8, $this->source); })())) {
            // line 9
            echo "<form action=\"";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("db_list", ["db" => (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 9, $this->source); })())]), "html", null, true);
            echo "\" method=\"post\" name=\"formTableList\" id=\"formTableList\">

    <input type=\"hidden\" name=\"tableMulty\" value=\"1\" />
    <input type=\"hidden\" name=\"action\" value=\"\" />



    <table class=\"contentTable\">
        <thead>

        <tr>
            <th>&nbsp;</th>
            <th><b>Таблица</b></th>
            <th>&nbsp;</th>
            <th>&nbsp;</th>
            <th>&nbsp;</th>
            <th>&nbsp;</th>
            <th><b>Рядов</b></th>
            <th><b>Размер</b></th>
            <th><b>Дата обновления</b></th>
            <th><b>Ai</b></th>
            <th>Engine</th>
            <th>Cp</th>
        </tr></thead>
        <tbody>

        ";
            // line 35
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 35, $this->source); })()));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["table"] => $context["info"]) {
                // line 36
                echo "        <tr id=\"row";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 36), "html", null, true);
                echo "\">
            <td id=\"row";
                // line 37
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 37), "html", null, true);
                echo "-0\"><input name=\"table[]\" type=\"checkbox\" value=\"migration\" id=\"table_migration\" class=\"cb\" onclick=\"checkboxer(1, '#row');\"></td>
            <td class=\"tbl\" id=\"row";
                // line 38
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 38), "html", null, true);
                echo "-1\"><label for=\"table_migration\">";
                echo twig_escape_filter($this->env, $context["table"], "html", null, true);
                echo "</label></td>
            <td id=\"row";
                // line 39
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 39), "html", null, true);
                echo "-2\"><a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("tbl_data", ["db" => (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 39, $this->source); })()), "table" => $context["table"]]), "html", null, true);
                echo "\" title=\"Обзор таблицы\"><img src=\"";
                echo twig_escape_filter($this->env, (isset($context["MS_DIR_IMG"]) || array_key_exists("MS_DIR_IMG", $context) ? $context["MS_DIR_IMG"] : (function () { throw new RuntimeError('Variable "MS_DIR_IMG" does not exist.', 39, $this->source); })()), "html", null, true);
                echo "actions.gif\" alt=\"\"></a></td>
            <td id=\"row";
                // line 40
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 40), "html", null, true);
                echo "-3\"><a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("tbl_struct", ["db" => (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 40, $this->source); })()), "table" => $context["table"]]), "html", null, true);
                echo "\" title=\"Структура таблицы\"><img src=\"";
                echo twig_escape_filter($this->env, (isset($context["MS_DIR_IMG"]) || array_key_exists("MS_DIR_IMG", $context) ? $context["MS_DIR_IMG"] : (function () { throw new RuntimeError('Variable "MS_DIR_IMG" does not exist.', 40, $this->source); })()), "html", null, true);
                echo "generate.png\" alt=\"\"></a></td>
            <td id=\"row";
                // line 41
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 41), "html", null, true);
                echo "-4\"><a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("tbl_list", ["db" => (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 41, $this->source); })()), "table" => $context["table"], "action" => "tableTruncate"]), "html", null, true);
                echo "\" class=\"confirm\" title=\"Очистить таблицу\"><img src=\"";
                echo twig_escape_filter($this->env, (isset($context["MS_DIR_IMG"]) || array_key_exists("MS_DIR_IMG", $context) ? $context["MS_DIR_IMG"] : (function () { throw new RuntimeError('Variable "MS_DIR_IMG" does not exist.', 41, $this->source); })()), "html", null, true);
                echo "delete.gif\" alt=\"\"></a></td>
            <td id=\"row";
                // line 42
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 42), "html", null, true);
                echo "-5\"><img src=\"";
                echo twig_escape_filter($this->env, (isset($context["MS_DIR_IMG"]) || array_key_exists("MS_DIR_IMG", $context) ? $context["MS_DIR_IMG"] : (function () { throw new RuntimeError('Variable "MS_DIR_IMG" does not exist.', 42, $this->source); })()), "html", null, true);
                echo "close.png\" data-action=\"tableDelete\" title=\"Удалить таблицу\" alt=\"\"></td>
            <td class=\"rig\" id=\"row";
                // line 43
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 43), "html", null, true);
                echo "-6\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["info"], "Rows", [], "array", false, false, false, 43), "html", null, true);
                echo "</td>
            <td class=\"rig\" id=\"row";
                // line 44
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 44), "html", null, true);
                echo "-7\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["info"], "Data_length", [], "array", false, false, false, 44), "html", null, true);
                echo "</td>
            <td id=\"row";
                // line 45
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 45), "html", null, true);
                echo "-8\"></td>
            <td class=\"num\" id=\"row";
                // line 46
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 46), "html", null, true);
                echo "-9\"></td>
            <td><span>";
                // line 47
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["info"], "Engine", [], "array", false, false, false, 47), "html", null, true);
                echo "</span></td>
            <td class=\"rig\"><span title=\"";
                // line 48
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["info"], "Collation", [], "array", false, false, false, 48), "html", null, true);
                echo "\" style=\"color:#aaa\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["info"], "Collation", [], "array", false, false, false, 48), "html", null, true);
                echo "</span></td>
        </tr>
        ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['table'], $context['info'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 51
            echo "        <tr>
            <td>&nbsp;</td>
            <td class=\"tbl\">x таблиц</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td class=\"rig\">x</td>
            <td class=\"rig\">x кб</td>
            <td>&nbsp;</td>
            <td class=\"num\">&nbsp;</td>
            <td>&nbsp;</td>
            <td class=\"rig\">&nbsp;</td>
        </tr></tbody>
    </table>

    <div class=\"chbxAction\">
        <img src=\"";
            // line 68
            echo twig_escape_filter($this->env, (isset($context["MS_DIR_IMG"]) || array_key_exists("MS_DIR_IMG", $context) ? $context["MS_DIR_IMG"] : (function () { throw new RuntimeError('Variable "MS_DIR_IMG" does not exist.', 68, $this->source); })()), "html", null, true);
            echo "arrow_ltr.png\" alt=\"\"  />
        <a href=\"#\" onClick=\"chbx_action('formTableList', 'check', 'table[]'); return false\" id=\"chooseAll\">выбрать все</a>  &nbsp;
        <a href=\"#\" onClick=\"chbx_action('formTableList', 'uncheck', 'table[]'); return false\">очистить</a>
    </div>

    <div class=\"imageAction\">
        <u>Выбранные</u>
        <img src=\"";
            // line 75
            echo twig_escape_filter($this->env, (isset($context["MS_DIR_IMG"]) || array_key_exists("MS_DIR_IMG", $context) ? $context["MS_DIR_IMG"] : (function () { throw new RuntimeError('Variable "MS_DIR_IMG" does not exist.', 75, $this->source); })()), "html", null, true);
            echo "close.png\" alt=\"\" onClick=\"msImageAction('formTableList', 'delete_all')\" />
        <img src=\"";
            // line 76
            echo twig_escape_filter($this->env, (isset($context["MS_DIR_IMG"]) || array_key_exists("MS_DIR_IMG", $context) ? $context["MS_DIR_IMG"] : (function () { throw new RuntimeError('Variable "MS_DIR_IMG" does not exist.', 76, $this->source); })()), "html", null, true);
            echo "delete.gif\" alt=\"\" onClick=\"msImageAction('formTableList', 'truncate_all')\" />
        <img src=\"";
            // line 77
            echo twig_escape_filter($this->env, (isset($context["MS_DIR_IMG"]) || array_key_exists("MS_DIR_IMG", $context) ? $context["MS_DIR_IMG"] : (function () { throw new RuntimeError('Variable "MS_DIR_IMG" does not exist.', 77, $this->source); })()), "html", null, true);
            echo "copy.gif\" alt=\"\" onClick=\"msImageAction('formTableList', 'copy_all')\" />
        <img src=\"";
            // line 78
            echo twig_escape_filter($this->env, (isset($context["MS_DIR_IMG"]) || array_key_exists("MS_DIR_IMG", $context) ? $context["MS_DIR_IMG"] : (function () { throw new RuntimeError('Variable "MS_DIR_IMG" does not exist.', 78, $this->source); })()), "html", null, true);
            echo "b_tblexport.png\" alt=\"\" onClick=\"msImageAction('formTableList', 'export_all', '<?php echo MS_URL?>?db=";
            echo twig_escape_filter($this->env, (isset($context["currentDb"]) || array_key_exists("currentDb", $context) ? $context["currentDb"] : (function () { throw new RuntimeError('Variable "currentDb" does not exist.', 78, $this->source); })()), "html", null, true);
            echo "&s=export')\" />

        <a href=\"?db=<?php echo \$msc->db?>&makeMyIsam=1\">Конвертировать все в MyIsam</a>

        <select name=\"act\" onChange=\"msImageAction('formTableList', this.options[this.selectedIndex].value)\" >
            <option></option>
            <option value=\"check\">проверить</option>
            <option value=\"analyze\">анализ</option>
            <option value=\"optimize\">оптимизировать</option>
            <option value=\"repair\">починить</option>
            <option value=\"flush\">сбросить кэш</option>
        </select>

        <input type=\"hidden\" name=\"copy_struct\" value=\"1\" />
        <input type=\"hidden\" name=\"copy_data\" value=\"1\" />
    </div>

</form>



<div style=\"padding:10px 0; margin-bottom:10px; font-size:14px;\">
    <a href=\"?s=tbl_list&action=full\"  title=\"Отобразить простую таблицу с полными данными всех таблиц, полученными с помощью запроса SHOW TABLE STATUS\">Полная таблица</a>
    &nbsp;
    <a href=\"?s=tbl_list&action=structure\"  title=\"\">Исследование структуры таблиц</a>
</div>

<?php if (conf('showtableupdated') == '1') { ?>
<form name=\"form1\" method=\"post\" action=\"\">
    Показать таблицы обновлённые с <?php echo plDrawDateSelector(strtotime(date('m/d/Y')), 'ds_')?>
    <input type=\"submit\" value=\"Показать!\">
</form>
<?php } ?>

<script>
    \$('.tbl label').on('click', function() {
        let table = this.innerHTML;
        let newName = prompt('Новое имя', this.innerHTML)
        if (newName) {
            let q = 'db=<?=\$_GET['db']?>&s=<?=\$_GET['s']?>&table='+table+'&newName=' + newName + '&id='+\$(this).parent().attr('id');
            msQuery('tableRename', q);
        }
    })
</script>
";
        }
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "tbl_list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  256 => 78,  252 => 77,  248 => 76,  244 => 75,  234 => 68,  215 => 51,  196 => 48,  192 => 47,  188 => 46,  184 => 45,  178 => 44,  172 => 43,  166 => 42,  158 => 41,  150 => 40,  142 => 39,  136 => 38,  132 => 37,  127 => 36,  110 => 35,  80 => 9,  77 => 8,  70 => 7,  60 => 4,  53 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}
    Список таблиц {{ currentDb }}
{% endblock %}

{% block content %}
    {% if data %}
<form action=\"{{ path('db_list', {'db': currentDb}) }}\" method=\"post\" name=\"formTableList\" id=\"formTableList\">

    <input type=\"hidden\" name=\"tableMulty\" value=\"1\" />
    <input type=\"hidden\" name=\"action\" value=\"\" />



    <table class=\"contentTable\">
        <thead>

        <tr>
            <th>&nbsp;</th>
            <th><b>Таблица</b></th>
            <th>&nbsp;</th>
            <th>&nbsp;</th>
            <th>&nbsp;</th>
            <th>&nbsp;</th>
            <th><b>Рядов</b></th>
            <th><b>Размер</b></th>
            <th><b>Дата обновления</b></th>
            <th><b>Ai</b></th>
            <th>Engine</th>
            <th>Cp</th>
        </tr></thead>
        <tbody>

        {% for table, info in data %}
        <tr id=\"row{{ loop.index }}\">
            <td id=\"row{{ loop.index }}-0\"><input name=\"table[]\" type=\"checkbox\" value=\"migration\" id=\"table_migration\" class=\"cb\" onclick=\"checkboxer(1, '#row');\"></td>
            <td class=\"tbl\" id=\"row{{ loop.index }}-1\"><label for=\"table_migration\">{{ table }}</label></td>
            <td id=\"row{{ loop.index }}-2\"><a href=\"{{ path('tbl_data', {'db': currentDb, 'table': table}) }}\" title=\"Обзор таблицы\"><img src=\"{{ MS_DIR_IMG }}actions.gif\" alt=\"\"></a></td>
            <td id=\"row{{ loop.index }}-3\"><a href=\"{{ path('tbl_struct', {'db': currentDb, 'table': table}) }}\" title=\"Структура таблицы\"><img src=\"{{ MS_DIR_IMG }}generate.png\" alt=\"\"></a></td>
            <td id=\"row{{ loop.index }}-4\"><a href=\"{{ path('tbl_list', {'db': currentDb, 'table': table, 'action': 'tableTruncate'}) }}\" class=\"confirm\" title=\"Очистить таблицу\"><img src=\"{{ MS_DIR_IMG }}delete.gif\" alt=\"\"></a></td>
            <td id=\"row{{ loop.index }}-5\"><img src=\"{{ MS_DIR_IMG }}close.png\" data-action=\"tableDelete\" title=\"Удалить таблицу\" alt=\"\"></td>
            <td class=\"rig\" id=\"row{{ loop.index }}-6\">{{ info['Rows'] }}</td>
            <td class=\"rig\" id=\"row{{ loop.index }}-7\">{{ info['Data_length'] }}</td>
            <td id=\"row{{ loop.index }}-8\"></td>
            <td class=\"num\" id=\"row{{ loop.index }}-9\"></td>
            <td><span>{{ info['Engine'] }}</span></td>
            <td class=\"rig\"><span title=\"{{ info['Collation'] }}\" style=\"color:#aaa\">{{ info['Collation'] }}</span></td>
        </tr>
        {% endfor %}
        <tr>
            <td>&nbsp;</td>
            <td class=\"tbl\">x таблиц</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td class=\"rig\">x</td>
            <td class=\"rig\">x кб</td>
            <td>&nbsp;</td>
            <td class=\"num\">&nbsp;</td>
            <td>&nbsp;</td>
            <td class=\"rig\">&nbsp;</td>
        </tr></tbody>
    </table>

    <div class=\"chbxAction\">
        <img src=\"{{ MS_DIR_IMG }}arrow_ltr.png\" alt=\"\"  />
        <a href=\"#\" onClick=\"chbx_action('formTableList', 'check', 'table[]'); return false\" id=\"chooseAll\">выбрать все</a>  &nbsp;
        <a href=\"#\" onClick=\"chbx_action('formTableList', 'uncheck', 'table[]'); return false\">очистить</a>
    </div>

    <div class=\"imageAction\">
        <u>Выбранные</u>
        <img src=\"{{ MS_DIR_IMG }}close.png\" alt=\"\" onClick=\"msImageAction('formTableList', 'delete_all')\" />
        <img src=\"{{ MS_DIR_IMG }}delete.gif\" alt=\"\" onClick=\"msImageAction('formTableList', 'truncate_all')\" />
        <img src=\"{{ MS_DIR_IMG }}copy.gif\" alt=\"\" onClick=\"msImageAction('formTableList', 'copy_all')\" />
        <img src=\"{{ MS_DIR_IMG }}b_tblexport.png\" alt=\"\" onClick=\"msImageAction('formTableList', 'export_all', '<?php echo MS_URL?>?db={{ currentDb }}&s=export')\" />

        <a href=\"?db=<?php echo \$msc->db?>&makeMyIsam=1\">Конвертировать все в MyIsam</a>

        <select name=\"act\" onChange=\"msImageAction('formTableList', this.options[this.selectedIndex].value)\" >
            <option></option>
            <option value=\"check\">проверить</option>
            <option value=\"analyze\">анализ</option>
            <option value=\"optimize\">оптимизировать</option>
            <option value=\"repair\">починить</option>
            <option value=\"flush\">сбросить кэш</option>
        </select>

        <input type=\"hidden\" name=\"copy_struct\" value=\"1\" />
        <input type=\"hidden\" name=\"copy_data\" value=\"1\" />
    </div>

</form>



<div style=\"padding:10px 0; margin-bottom:10px; font-size:14px;\">
    <a href=\"?s=tbl_list&action=full\"  title=\"Отобразить простую таблицу с полными данными всех таблиц, полученными с помощью запроса SHOW TABLE STATUS\">Полная таблица</a>
    &nbsp;
    <a href=\"?s=tbl_list&action=structure\"  title=\"\">Исследование структуры таблиц</a>
</div>

<?php if (conf('showtableupdated') == '1') { ?>
<form name=\"form1\" method=\"post\" action=\"\">
    Показать таблицы обновлённые с <?php echo plDrawDateSelector(strtotime(date('m/d/Y')), 'ds_')?>
    <input type=\"submit\" value=\"Показать!\">
</form>
<?php } ?>

<script>
    \$('.tbl label').on('click', function() {
        let table = this.innerHTML;
        let newName = prompt('Новое имя', this.innerHTML)
        if (newName) {
            let q = 'db=<?=\$_GET['db']?>&s=<?=\$_GET['s']?>&table='+table+'&newName=' + newName + '&id='+\$(this).parent().attr('id');
            msQuery('tableRename', q);
        }
    })
</script>
{% endif %}
{% endblock %}", "tbl_list.html.twig", "F:\\OpenServer\\domains\\framework\\symfony-msc\\templates\\tbl_list.html.twig");
    }
}
