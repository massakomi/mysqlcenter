<?php

namespace ContainerW9vKvki;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolderb575b = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer127cd = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicPropertiese35d1 = [
        
    ];

    public function getConnection()
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'getConnection', array(), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'getMetadataFactory', array(), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'getExpressionBuilder', array(), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'beginTransaction', array(), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->beginTransaction();
    }

    public function getCache()
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'getCache', array(), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->getCache();
    }

    public function transactional($func)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'transactional', array('func' => $func), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'wrapInTransaction', array('func' => $func), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'commit', array(), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->commit();
    }

    public function rollback()
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'rollback', array(), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'getClassMetadata', array('className' => $className), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'createQuery', array('dql' => $dql), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'createNamedQuery', array('name' => $name), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'createQueryBuilder', array(), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'flush', array('entity' => $entity), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'clear', array('entityName' => $entityName), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->clear($entityName);
    }

    public function close()
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'close', array(), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->close();
    }

    public function persist($entity)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'persist', array('entity' => $entity), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'remove', array('entity' => $entity), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'refresh', array('entity' => $entity), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'detach', array('entity' => $entity), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'merge', array('entity' => $entity), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'getRepository', array('entityName' => $entityName), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'contains', array('entity' => $entity), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'getEventManager', array(), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'getConfiguration', array(), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'isOpen', array(), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'getUnitOfWork', array(), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'getProxyFactory', array(), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'initializeObject', array('obj' => $obj), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'getFilters', array(), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'isFiltersStateClean', array(), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'hasFilters', array(), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return $this->valueHolderb575b->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializer127cd = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolderb575b) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolderb575b = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolderb575b->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, '__get', ['name' => $name], $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        if (isset(self::$publicPropertiese35d1[$name])) {
            return $this->valueHolderb575b->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderb575b;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderb575b;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderb575b;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderb575b;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, '__isset', array('name' => $name), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderb575b;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolderb575b;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, '__unset', array('name' => $name), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderb575b;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolderb575b;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, '__clone', array(), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        $this->valueHolderb575b = clone $this->valueHolderb575b;
    }

    public function __sleep()
    {
        $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, '__sleep', array(), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;

        return array('valueHolderb575b');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer127cd = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer127cd;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer127cd && ($this->initializer127cd->__invoke($valueHolderb575b, $this, 'initializeProxy', array(), $this->initializer127cd) || 1) && $this->valueHolderb575b = $valueHolderb575b;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolderb575b;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolderb575b;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
