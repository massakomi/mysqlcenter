<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/' => [[['_route' => 'db_list', '_controller' => 'App\\Controller\\DefaultController::index'], null, null, null, false, false, null]],
        '/tbl_list' => [[['_route' => 'tbl_list', '_controller' => 'App\\Controller\\DefaultController::tbl_list'], null, null, null, false, false, null]],
        '/tbl_data' => [[['_route' => 'tbl_data', '_controller' => 'App\\Controller\\DefaultController::tbl_data'], null, null, null, false, false, null]],
        '/tbl_add' => [[['_route' => 'tbl_add', '_controller' => 'App\\Controller\\DefaultController::tbl_add'], null, null, null, false, false, null]],
        '/tbl_struct' => [[['_route' => 'tbl_struct', '_controller' => 'App\\Controller\\DefaultController::tbl_struct'], null, null, null, false, false, null]],
        '/users' => [[['_route' => 'users', '_controller' => 'App\\Controller\\DefaultController::users'], null, ['POST' => 0], null, false, false, null]],
        '/server_status' => [[['_route' => 'server_status', '_controller' => 'App\\Controller\\DefaultController::server_status'], null, null, null, false, false, null]],
        '/server_variables' => [[['_route' => 'server_variables', '_controller' => 'App\\Controller\\DefaultController::server_variables'], null, null, null, false, false, null]],
        '/server_users' => [[['_route' => 'server_users', '_controller' => 'App\\Controller\\DefaultController::server_users'], null, null, null, false, false, null]],
        '/export' => [[['_route' => 'export', '_controller' => 'App\\Controller\\DefaultController::export'], null, null, null, false, false, null]],
        '/search' => [[['_route' => 'search', '_controller' => 'App\\Controller\\DefaultController::search'], null, null, null, false, false, null]],
        '/sql' => [[['_route' => 'sql', '_controller' => 'App\\Controller\\DefaultController::sql'], null, null, null, false, false, null]],
        '/actions' => [[['_route' => 'actions', '_controller' => 'App\\Controller\\DefaultController::actions'], null, null, null, false, false, null]],
        '/logout' => [[['_route' => 'logout', '_controller' => 'App\\Controller\\DefaultController::logout'], null, null, null, false, false, null]],
        '/msc_help' => [[['_route' => 'msc_help', '_controller' => 'App\\Controller\\DefaultController::msc_help'], null, null, null, false, false, null]],
        '/msc_configuration' => [[['_route' => 'msc_configuration', '_controller' => 'App\\Controller\\DefaultController::msc_configuration'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [
            [['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
