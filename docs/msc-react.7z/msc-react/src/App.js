import React, {useState, useEffect, useContext} from 'react';
import { GlobalMenu, ChainMenu, FooterMenu, PopupQueryForm, SearchInTable, msDisplaySql, AppLogin, Messages } from './components/all';
import {BrowserRouter, Outlet} from "react-router-dom";
import { showhide } from "./utils";
import { apiQuery } from "./utils";


function App() {

  const [data, setData] = useState({main: {page: ''}});

  useEffect(() => {
    const fetchData = async () => {
      let json = await apiQuery('init=1')
      setData(json);
    };
    //console.log('use eff')
    fetchData();
  }, []);

  console.log(data.main)

  if (data.main && data.main.page) {
    document.title = data.getWindowTitle
    if (data.main.page === 'login') {
      return <AppLogin {...data} />
    } else {
      return <AppMain {...data} />
    }
  } else {
    return (
      <>
        Страница загружается...
      </>
    )
  }
  /*

  if (props.page === 'login') {
    return <AppLogin {...props} />
  } else {
    return <AppMain {...props} />
  }*/
}

export const OptionsContext = React.createContext('значение по умолчанию');

function AppMain(props) {

  let options = {param: 1, value: '2) Это текст тулбара, передан через контекст'}

  //const options = useContext(OptionsContext);
  //console.log(options)

  //console.log(props.main)
  return (
    <OptionsContext.Provider value={options}>
    <div className="App">
      <div className="pageBlock">
        <b id="appNameId"><a href="?db_list">MySQL React</a></b> &nbsp; &nbsp;
        <GlobalMenu {...props.main} /> &nbsp; &nbsp;
        <span className="hiddenText" onClick={msDisplaySql} title="Кликните, чтобы открыть форму быстрого запроса">{props.generate_time} с. &nbsp;&nbsp;  </span>
        <span className="menuChain"><ChainMenu /></span>
      </div>

      <table width="100%" className="outerTable">
        <tbody>
        <tr>
          <td width="100" className="tableMenuTd">
            getTableMenu
          </td>
          <td>
            <table width="800">
              <tbody>
              <tr>
                <td width="500"><h1>{props.getPageTitle}</h1></td>
                <td style={{whiteSpace: 'nowrap'}}>
                  <span className="hiddenText" onClick={showhide.bind(this, 'queryPopupBlock')}>запросы&nbsp;</span>
                  {props.queries.length}
                  &nbsp;&nbsp;
                  <SearchInTable />
                </td>
              </tr>
              </tbody>
            </table>
            <Messages messages={props.messages} />
            <Outlet />
          </td>
          <td>
            <div id="msAjaxQueryDiv">*</div>
          </td>
        </tr>
        </tbody>
      </table>

      <PopupQueryForm />

      <div id="dbHiddenMenu">

      </div>
      <div id="queryPopupBlock">
        {props.queries.map((q, key) =>
          <span key={key}>{q}</span>
        )}
      </div>

      <div className="pageBlock">
        <FooterMenu/> &nbsp;&nbsp;&nbsp;
        &nbsp; &nbsp; &nbsp;
        <strong>Хост:</strong> {props.DB_HOST}&nbsp;&nbsp;
        <strong>Пользователь:</strong> {props.DB_USERNAME_CUR}&nbsp;

        пиковая память {props.memory_get_peak_usage} &nbsp;
        сейчас {props.memory_get_usage} &nbsp;
        inc {props.includeSize}
        limit {props.memory_limit} &nbsp;&nbsp;

        <strong><a href="?s=logout">Выход</a></strong>
      </div>

    </div>
    </OptionsContext.Provider>
  );
}





export default App;
