import help from "../images/help.gif";
import React from "react";
import jQuery from "jquery";
import { Outlet, Link, NavLink } from "react-router-dom";
import { useLocation } from 'react-router-dom'
import {apiQuery} from "../utils";

let UrlMaker = {
  make(param, value) {
    return `?${param}=${value}`
  }
}

export const msDisplaySql = () => {
  if (jQuery('#sqlPopupQueryForm').is(':visible')) {
    jQuery('#sqlPopupQueryForm').hide()
  } else {
    jQuery('#sqlPopupQueryForm').show().find('textarea').focus()
  }
}

export function GlobalMenu(props) {
  const location = useLocation();
  let dbMenuGlobal = [
    ['delim'],
    ['поиск', 'search', ''],
    ['экспорт', 'export', ''],
    ['sql', 'sql', ''],
    ['операции', 'actions', '']
  ]
  let type = 'table';
  if (location.pathname === '/db_list' || props.page === 'db_list' || props.page === 'users' || location.pathname.startsWith('server_')) {
    type = 'server';
    dbMenuGlobal = [
      ['базы данных', 'db_list', ''],
      ['статус', 'server_status', ''],
      ['переменные', 'server_variables', ''],
      //['кодировки', 'server_collations', ''],
      ['инфо', 'server_users', ''],
    ].concat(dbMenuGlobal)
  } else if ((props.db !== '' && props.table === '') || props.page === 'tbl_list') {
    type = 'db'
    dbMenuGlobal = [
      ['базы таблицы', 'tbl_list', ''],
      ['создать таблицу', 'tbl_add', ''],
    ].concat(dbMenuGlobal).concat([
      ['delim'],
      ['очистить', props.page, 'dbTruncate'],
      ['удалить', props.page, 'dbDelete'],
      ['удалить таблицы', props.page, 'dbTablesDelete'],
    ])
  } else {
    dbMenuGlobal = [
      ['обзор', 'tbl_data', ''],
      ['структура', 'tbl_struct', ''],
      ['вставить', 'tbl_change', ''],
      ['создать таблицу', 'tbl_add', '', '?db='+props.db],
    ].concat(dbMenuGlobal).concat([
      ['delim'],
      ['очистить', props.page, 'tableTruncate'],
      ['удалить', props.page, 'tableDelete'],
    ])
  }

  const activeChecker = ( {isActive} ) => {return isActive ? 'cur' : ''}
  let menu = []
  for (let item of dbMenuGlobal) {
    let title = item[0]
    if (title === 'delim') {
      menu.push(<b key={menu.length} className="delim">|</b>);
      continue;
    }
    let page = item[1]
    let action = item[2]
    let curl = page;
    if (action) {
      curl += '?action='+action;
    }
    /*$extra = null;
    if (stristr($action, 'delete')) {
      $extra = ' class="delete" onClick="check(this, \'удаление\'); return false"';
    } elseif (stristr($action, 'truncate')) {
      $extra = ' class="truncate" onClick="check(this, \'очистка\'); return false"';
    }*/
    menu.push(<NavLink key={menu.length} className={activeChecker} to={curl}>{title}</NavLink>)
  }
  return <div className="globalMenu" id="globalMenu">{menu}</div>
}


export function ChainMenu() {
  let chain = []
  chain.push(<a key="c0" href="?s=db_list">DB</a>)
  let db = 'any'
  if (db) {
    chain.push(<a key="c1" href={`?s=tbl_list&db=${db}&action=structure`}>&#8250;</a>)
    chain.push(<a key="c2" href={`?s=tbl_list&db=${db}`}>{db}</a>)
  }
  let table = 'table'
  let page = 'tbl_list'
  if (table) {
    chain.push(<span key="c3">&#8250;</span>)
    chain.push(<a key="c4" href={`?s=tbl_data&db=${db}&table=${table}`}>{table}</a>)
    if (page !== 'tbl_data') {
      chain.push(<span key="c5">&#8250;</span>)
      chain.push(<a key="c6" href={`?s=${page}&db=${db}&table=${table}`}>{page}</a>)
    }
  }
  return chain
}

export function FooterMenu() {
  return (
    <div className="globalMenu">
      <a href="?s=msc_help"> <img src={help} title="MySQL справка" align="absbottom" alt="" border="0" /></a>
      <a href="?s=msc_configuration">Настройки</a>
    </div>
  )
}

export function PopupQueryForm() {
  let url = UrlMaker.make('s', 'sql')
  return (
    <form action={url} className="popupGeneralForm tableFormEdit" method="post"
          name="sqlPopupQueryForm" id="sqlPopupQueryForm" style={{textAlign: 'right'}}>
      <input type="submit" value="Отправить запрос!"/>
      <textarea name="sql" rows="15" wrap="off"></textarea>
      <span onClick={msDisplaySql}>закрыть</span>
    </form>
  )
}

export function SearchInTable() {

  const clearVal = (e) => (e.target.value = '')

  const appendQuery = (e) => {
    e.target.action = e.target.action + '&query='+e.target.query.value
  }

  var table = new URLSearchParams(window.location.search).get('table');
  let forms = []
  let db = ''
  if (table !== '') {
    let url = `?s=tbl_data&db=${db}&table=${table}`
    forms.push(
      <form key="f1" action={url} method="post" style={{display:'inline'}} onSubmit={appendQuery.bind(this)}>
        <input type="text" name="query" defaultValue="Поиск по таблице" onFocus={clearVal.bind(this)} />
      </form>
    )
  }
  let url = `?s=search&db=${db}`
  forms.push(
    <form key="f2" action={url} method="post" style={{display:'inline'}} onSubmit={appendQuery.bind(this)}>
      <input type="text" name="query" defaultValue="Поиск по базе" onFocus={clearVal.bind(this)} />
    </form>
  )
  return <React.Fragment>{forms}</React.Fragment>
}

export function Messages(props) {
  let config = {
    showmessages: 1
  }
  //if (config.showmessages === 1) {
  return <div className="messages">{props.messages.map((item, key) =>
    <span key={key} style={{color: item.color}}>{item.text}</span>
  )}</div>
  //}
}


export class AppLogin extends React.Component {

  async doLogin(e) {
    e.preventDefault();
    let form = e.target;
    let json = await apiQuery('', {},form)
  }

  render() {
    return (
      <div className="page-login">
        <div className="message">
          {this.props.message}
        </div>
        <form method="post" onSubmit={this.doLogin}>
          <b>логин</b>
          <p><input type="text" name="user" defaultValue="root" /></p>
          <b>пароль</b>
          <p><input type="password" name="pass" defaultValue="root" /></p>
          <p style={{marginTop: '10px'}}><input type="submit" value="Enter" /></p>
        </form>
      </div>
    );
  }
}