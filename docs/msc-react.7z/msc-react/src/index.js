import React, {useContext, useEffect, useState} from 'react';
import ReactDOM from "react-dom/client";
import './css/page.css';
import './css/color.white.css';
import App from './App';
import DbList from './pages/db_list';
import ServerStatus from './pages/server_status';

import { BrowserRouter, Routes, Route } from "react-router-dom";
import OptionsContext from "./App";
import {apiQuery} from "./utils";
import jQuery from "jquery";

import reportWebVitals from './reportWebVitals';

/*
Как передать messages из server_status обновленный, после запроса? Как заставить обновиться компонент этот
Ну ок, я вывожу заголовк через jQuery, ну я так могу и все свойства выводить. А зачем тогда все это.
TODO применить contexter шаблон (а OptionsContext убрать) из реакта (там вроде как получилось реально передать данные messages)
* */

// async function renderApp() {
//   let json = await apiQuery('')

  /*ReactDOM.render(
    <App {...json} />,
    document.getElementById('root')
  );*/

  // Основной код - карта роутов

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <BrowserRouter>
    <Routes>
      <Route path="/" element={<App />}>
        <Route path="db_list" element={<DbList />} />
        <Route path="server_status" element={<ServerStatus />} />
        <Route index element={<DbList />} />
        <Route
          path="*"
          element={
            <main style={{ color: "red" }}>
              <p>404 error</p>
            </main>
          }
        />
      </Route>
    </Routes>
  </BrowserRouter>
);

// }

// renderApp()




/*
ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);
*/

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
